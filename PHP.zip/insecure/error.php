<?
  include_once("./common.php");
  $value = $_GET["value"];
?>
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
      <h1 class="display-4">"<?=$value?>" Page Not Found</h1>
      <hr>
    </div>
