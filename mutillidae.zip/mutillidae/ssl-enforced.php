<div class="page-title">Browsing via HTTP Forbidden</div>
<div>&nbsp;</div>
<table>
	<tr id="id-bad-page-tr">
		<td colspan="2" class="error-message">
			Mutillidae is currently running in a high-security mode and SSL is enforced. 
			Browsing to non-SSL (HTTP) pages is not permitted. 
			Redirecting automatically made lead to an SSL striping attack. 
			Please type "https" at the start of the URL in the browser bar. 
		</td>
	</tr>
</table>