<?php
$lLabNumber = 47;
$lTitle = "Lab 47: Error Handling - Testing for Errors";
$lQuestion = "What does the error message reveal when a single-quote is injected into the login page within Mutillidae?";
$lChoice_1 = "The brand of database in use";
$lChoice_2 = "The kernel version of Linux operating system";
$lChoice_3 = "The password for user Kevin";
$lChoice_4 = "The password hash for user Kevin";
$lChoice_5 = "Mutillidae does not display error messages";
$lCorrectAnswer = 1;

require_once("labs/lab-template.inc");
?>