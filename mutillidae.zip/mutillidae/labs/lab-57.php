<?php
$lLabNumber = 57;
$lTitle = "Lab 57: JSON Web Token (JWT) Security - Missing Signature Validation";
$lQuestion = "Using the Current User Information page, who has the user ID 3?";
$lChoice_1 = "Fred";
$lChoice_2 = "Sally";
$lChoice_3 = "Joe";
$lChoice_4 = "Amanda";
$lChoice_5 = "John";
$lCorrectAnswer = 5;

require_once("labs/lab-template.inc");
?>
