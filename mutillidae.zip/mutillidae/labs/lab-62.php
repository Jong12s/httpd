<?php
$lLabNumber = 62;
$lTitle = "Lab 62: Software Composition Analysis - Retire.js";
$lQuestion = "Which popular open-source JavaScript library does Retire.js state has not been keep up to date in Mutillidae II?";
$lChoice_1 = "Angular";
$lChoice_2 = "Bootstrap";
$lChoice_3 = "jQuery";
$lChoice_4 = "Serialize";
$lChoice_5 = "Zod";
$lCorrectAnswer = 3;

require_once("labs/lab-template.inc");
?>
