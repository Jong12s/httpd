<?php
    $lLabNumber = 3;
    $lTitle = "Lab 3: How the web really works - Intercepting HTTP Requests and Responses";
    $lQuestion = "In Burp-Suite, under Proxy -> Options -> Intercept Web Socket Messages, in which direction can Burp-Suite intercept messages?";
    $lChoice_1 = "Client-to-Server";
    $lChoice_2 = "Server-to-Client";
    $lChoice_3 = "Bidirectional";
    $lChoice_4 = "There is no support";
    $lChoice_5 = "None of the above";
    $lCorrectAnswer = 3;

    require_once("labs/lab-template.inc");
?>