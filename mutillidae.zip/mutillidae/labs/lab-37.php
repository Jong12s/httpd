<?php
    $lLabNumber = 37;
    $lTitle = "Lab 37: Cookie Management - Show Hints";
    $lQuestion = "Referring to lab Cookie Management - Show Hints, what value(s) cause hints to show?";
    $lChoice_1 = "Any negative value";
    $lChoice_2 = "0";
    $lChoice_3 = "Any positive value";
    $lChoice_4 = "There is no way to cause the hints to show";
    $lChoice_5 = "There is no way to keep the hints from showing";
    $lCorrectAnswer = 3;

    require_once("labs/lab-template.inc");
?>