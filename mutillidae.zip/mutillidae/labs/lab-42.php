<?php
$lLabNumber = 42;
$lTitle = "Lab 42: Input Validation - Input Validation";
$lQuestion = "How does the input validation on the DNS Lookup page protect the input field when the security is set to level 5?";
$lChoice_1 = "The input validation identifies evil input and blocks it";
$lChoice_2 = "The input validation blocks all input";
$lChoice_3 = "The input validation alerts security if the user enters the wrong value";
$lChoice_4 = "The input validation only allows legitimate values";
$lChoice_5 = "The input validation does not work";
$lCorrectAnswer = 4;

require_once("labs/lab-template.inc");
?>