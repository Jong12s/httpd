<?php
$lLabNumber = 38;
$lTitle = "Lab 38: Cookie Management - Privilege Escalation";
$lQuestion = "Referring to lab Cookie Management - Privilege Escalation, which user has UID of 1?";
$lChoice_1 = "jeremy";
$lChoice_2 = "bryce";
$lChoice_3 = "mary";
$lChoice_4 = "fred";
$lChoice_5 = "admin";
$lCorrectAnswer = 5;

require_once("labs/lab-template.inc");
?>