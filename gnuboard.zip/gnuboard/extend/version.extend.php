<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// 자바스크립트와 CSS 파일을 새로 다운로드 하도록 파일의 끝에 년월일 지정
// 예) https://도메인/css/default.css?ver=220620
// 예) https://도메인/js/common.js?ver=220620
define('G5_CSS_VER', '2303229');
define('G5_JS_VER',  '2304171');
